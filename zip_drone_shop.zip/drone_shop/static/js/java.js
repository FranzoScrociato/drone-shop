// Gestione popup prodotto
document.querySelectorAll('.open-popup-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        document.getElementById('popup-img').src = btn.dataset.img;
        document.getElementById('popup-title').textContent = btn.dataset.title;
        document.getElementById('popup-desc').textContent = btn.dataset.desc;
        const features = btn.dataset.features.split('\\n');
        const ul = document.getElementById('popup-features');
        ul.innerHTML = '';
        features.forEach(f => {
            if (f.trim()) {
                const li = document.createElement('li');
                li.textContent = f.replace(/^•\s?/, '');
                ul.appendChild(li);
            }
        });
        document.getElementById('popup-price').textContent = btn.dataset.price + ' €';
        const popupForm = document.getElementById('popup-add-form');
        popupForm.setAttribute('data-product-id', btn.dataset.id);
        document.getElementById('product-overlay').classList.add('active');
    });
});

// Chiudi popup
document.getElementById('popup-close').onclick = function() {
    document.getElementById('product-overlay').classList.remove('active');
};
// Chiudi cliccando fuori dal popup
document.getElementById('product-overlay').onclick = function(e) {
    if (e.target === this) this.classList.remove('active');
};
// Gestisci aggiunta al carrello dal popup
document.getElementById('popup-add-form').addEventListener('submit', function(e) {
    e.preventDefault();
    const productId = this.getAttribute('data-product-id');
    fetch(window.addToCartUrl, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-Requested-With': 'XMLHttpRequest'
        },
        body: 'product_id=' + encodeURIComponent(productId)
    })
    .then(response => response.json())
    .then(data => {
        showToast(data.message || 'Prodotto aggiunto al carrello!');
        updateCartCounter();
        document.getElementById('product-overlay').classList.remove('active');
    });
});

function showToast(msg) {
    const toast = document.getElementById('toast');
    toast.textContent = msg;
    toast.style.display = 'block';
    toast.style.opacity = '1';
    setTimeout(() => {
        toast.style.opacity = '0';
        setTimeout(() => { toast.style.display = 'none'; }, 400);
    }, 1700);
}

function updateCartCounter() {
    fetch(window.cartCountUrl)
        .then(response => response.json())
        .then(data => {
            const counter = document.getElementById('cart-counter');
            if (counter) {
                counter.textContent = data.count;
                counter.style.display = data.count > 0 ? 'inline-block' : 'none';
            }
        });
}

document.addEventListener('DOMContentLoaded', function() {
    updateCartCounter();
    document.querySelectorAll('.add-to-cart-form').forEach(form => {
        // Evita doppio handler sul form popup
        if(form.id === 'popup-add-form') return;
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            const productId = form.getAttribute('data-product-id');
            fetch(window.addToCartUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: 'product_id=' + encodeURIComponent(productId)
            })
            .then(response => response.json())
            .then(data => {
                showToast(data.message || 'Prodotto aggiunto al carrello!');
                updateCartCounter();
            });
        });
    });
});