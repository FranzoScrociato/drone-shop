from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
import sqlite3
import os
import re
from datadb.database import init_db  # Assicurati che questo file esista e funzioni
from flask_mail import Mail, Message



# Configurazione di Flask con cartelle personalizzate
app = Flask(__name__, template_folder="templates", static_folder="static")
app.secret_key = os.urandom(24)
app.config['SECRET_KEY'] = 'una_chiave_segreta_molto_sicura'

# Funzione per connettersi al database SQLite
def get_db_connection():
    conn = sqlite3.connect('users.db')
    conn.row_factory = sqlite3.Row
    return conn

# Configurazione per Flask-Mail
app.config['MAIL_SERVER'] = 'smtp.gmail.com'  # Server SMTP di Gmail
app.config['MAIL_PORT'] = 587  # Porta per la connessione SMTP
app.config['MAIL_USE_TLS'] = True  # Usare TLS
app.config['MAIL_USERNAME'] = 'skyvibesdroneshop@gmail.com'  # La tua email
app.config['MAIL_PASSWORD'] = 'xjhfwhbvjxprbuep'  # La password della tua email (o una password per app se usi l'autenticazione a due fattori)
app.config['MAIL_DEFAULT_SENDER'] = 'skyvibesdroneshop@gmail.com'

PRODUCTS = {
    "drone1": {"nome": "X Fly Pro", "prezzo": 149.99, "prezzo_originale": 199.99, "img": "immagini/drone1.jpg"},
    "drone2": {"nome": "X Fly", "prezzo": 179.99, "img": "immagini/drone2.jpg"},
    "drone3": {"nome": "Drone SkyVibes Pro", "prezzo": 129.99, "img": "immagini/drone3.jpg"},
    "drone4": {"nome": "Drone UltraX", "prezzo": 249.99, "img": "immagini/drone4.jpg"},
    "drone5": {"nome": "SkyVibes Platinum Pro", "prezzo": 1499.99, "img": "immagini/drone5.jpg"},
}

mail = Mail(app)

# Route per la home (pagina negozio)
@app.route('/')
def home():
    if 'user' in session:
        return render_template('negozio.html', username=session['user'])
    return redirect(url_for('login'))

# Route per la pagina "shop"
@app.route('/shop')
def shop():
    if 'user' in session:
        return render_template('shop.html', username=session['user'])
    return redirect(url_for('login'))

# Route per il login
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        conn = get_db_connection()
        # Controlla username e password (salvati in chiaro)
        user = conn.execute('SELECT * FROM users WHERE username = ? AND password = ?', (username, password)).fetchone()
        conn.close()

        if user:
            session['user'] = user['username']
            flash("Login effettuato con successo!", "success")
            return redirect(url_for('home'))
        else:
            flash("Nome utente o password errati", "danger")
            return redirect(url_for('login'))
    
    return render_template('login.html')

# Route per il logout
@app.route('/logout')
def logout():
    session.pop('user', None)
    flash("Logout effettuato con successo!", "success")
    return redirect(url_for('login'))
# Route per la pagina "Chi Siamo"
@app.route('/about')
def about():
    return render_template('about.html')
@app.route('/contact', methods=['GET', 'POST'])
def contact():
    if request.method == 'POST':
        # Ottieni i dati dal modulo
        name = request.form['name']
        email = request.form['email']
        message = request.form['message']

        email_regex = r'^[\w\.-]+@[\w\.-]+\.\w+$'
        if not re.match(email_regex, email):
            flash("Indirizzo email non valido!", "danger")
            return redirect(url_for('contact'))

        # Crea il messaggio da inviare via email
        msg = Message(
            'Nuovo messaggio da ' + name,  # Oggetto dell'email
            sender=app.config['MAIL_DEFAULT_SENDER'],  # Mittente
            recipients=['skyvibesdroneshop@gmail.com'],  # Destinatario
            body=f"Messaggio da {name} ({email}):\n\n{message}"  # Corpo del messaggio
        )

        # Invia l'email
        try:
            mail.send(msg)
            flash("Messaggio inviato con successo!", "success")
            return redirect(url_for('contact'))
        except Exception as e:
            print("Errore nell'invio dell'email:", e)
            flash(f"Errore nell'invio del messaggio: {str(e)}", "danger")
            return redirect(url_for('contact'))

    return render_template('contact.html')

# Route per la registrazione (senza conferma password)
@app.route('/registrazione', methods=['GET', 'POST'])
def registrazione():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']

        try:
            conn = get_db_connection()
            conn.execute('INSERT INTO users (username, email, password) VALUES (?, ?, ?)', 
                         (username, email, password))
            conn.commit()
            conn.close()
            flash("Registrazione completata con successo!", "success")
            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            flash("Nome utente o email già esistenti!", "danger")
            return redirect(url_for('registrazione'))

    return render_template('registrazione.html')

@app.route('/cart')
def cart():
    cart_ids = session.get('cart', [])
    cart_items = []
    for pid in cart_ids:
        if pid in PRODUCTS:
            cart_items.append({'id': pid, **PRODUCTS[pid]})
    return render_template('cart.html', cart_items=cart_items)

@app.route('/add_to_cart', methods=['POST'])
def add_to_cart():
    product_id = request.form.get('product_id')
    if not product_id or product_id not in PRODUCTS:
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return jsonify({'success': False, 'message': 'Prodotto non valido.'})
        flash("Prodotto non valido.")
        return redirect(url_for('shop'))
    cart = session.get('cart', [])
    cart.append(product_id)
    session['cart'] = cart
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify({'success': True, 'message': 'Prodotto aggiunto al carrello!', 'count': len(cart)})
    flash("Prodotto aggiunto al carrello!")
    return redirect(url_for('shop'))

@app.route('/remove_from_cart', methods=['POST'])
def remove_from_cart():
    product_id = request.form.get('product_id')
    cart = session.get('cart', [])
    if product_id in cart:
        cart.remove(product_id)
        session['cart'] = cart
        flash("Prodotto rimosso dal carrello.")
    return redirect(url_for('cart'))

@app.route('/cart_count')
def cart_count():
    cart = session.get('cart', [])
    return jsonify({'count': len(cart)})

if __name__ == '__main__':
    init_db()  # Inizializza il database prima di avviare il server
    print("Database creato o già esistente.")
    print("Avvio del server Flask...")
    app.run(debug=False)
