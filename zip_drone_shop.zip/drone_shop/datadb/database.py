import sqlite3

def init_db():
    """Inizializza il database e crea la tabella 'users' se non esiste."""
    try:
        conn = sqlite3.connect('users.db') 
        c = conn.cursor()

        c.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL UNIQUE,
                email TEXT NOT NULL UNIQUE,
                password TEXT NOT NULL
            )
        ''')

        conn.commit() 
    except sqlite3.Error as e:
        print(f"Errore durante l'inizializzazione del database: {e}")
    finally:
        conn.close()  